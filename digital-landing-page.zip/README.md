# Digital Landing Page

Landing page for digital services like subscriptions, activation codes, and social media engagement packages.

## Structure
- `index.html` — Main HTML entry point.
- `App.jsx` — React component with landing page layout.
- `App.css` — Custom styles.

## How to Deploy on GitHub Pages
1. Create a new GitHub repo.
2. Push this project.
3. Use GitHub Pages settings to publish from root or `main` branch.
